Build with: latexmk -pdf main.tex
Frozen, audited figures and number macros are included.
